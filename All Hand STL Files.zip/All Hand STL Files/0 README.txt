	To 3D print all parts requires:

1x Angled Knuckles
2x Complete Middle Finger
3x Finger Segments
1x Hand Top Plate
1x Palm Base Cover
1x Palm Motor Block
15x Pully
1x Thumb Bracket with Palm Plates
1x Thumb Knuckle

	Other parts that need producing:

10x Pivot Pins* as seen in the included STL file
6X  Pivot Pins* as seen in the included STL file without the D shaft cut away

*These require hand making optimally with use of a lathe.